import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:uuid/uuid.dart';
import '../models/trip.dart';
import '../providers/app_provider.dart';
import '../widgets/driver_card.dart';
import '../widgets/trip_form.dart';

class DispatcherScreen extends StatefulWidget {
  const DispatcherScreen({Key? key}) : super(key: key);

  @override
  State<DispatcherScreen> createState() => _DispatcherScreenState();
}

class _DispatcherScreenState extends State<DispatcherScreen> {
  void _showDriverSelectionDialog(BuildContext context, Trip trip) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('اختر سائقاً لهذه النقلة'),
          content: SizedBox(
            width: double.maxFinite,
            child: Consumer<AppProvider>(
              builder: (context, appProvider, _) {
                return ListView.builder(
                  shrinkWrap: true,
                  itemCount: appProvider.drivers.length,
                  itemBuilder: (context, index) {
                    final driver = appProvider.drivers[index];
                    return ListTile(
                      title: Text(driver.name),
                      subtitle: Text(driver.truckType),
                      onTap: () {
                        context.read<AppProvider>().addTrip(trip);
                        context.read<AppProvider>().assignDriverToTrip(trip.id, driver.id);
                        Navigator.pop(context);
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text('تم إسناد النقلة إلى ${driver.name}')),
                        );
                      },
                    );
                  },
                );
              },
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('لوحة تحكم الموزع'),
        centerTitle: true,
        backgroundColor: Colors.blue[700],
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // عنوان السائقين المتاحين
              Text(
                'السائقين المتاحين',
                style: Theme.of(context).textTheme.titleLarge,
              ),
              const SizedBox(height: 12),
              
              // قائمة السائقين
              Consumer<AppProvider>(
                builder: (context, appProvider, _) {
                  return ListView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: appProvider.drivers.length,
                    itemBuilder: (context, index) {
                      return DriverCard(
                        driver: appProvider.drivers[index],
                      );
                    },
                  );
                },
              ),
              
              const SizedBox(height: 24),
              
              // عنوان إنشاء نقلة جديدة
              Text(
                'إنشاء نقلة جديدة',
                style: Theme.of(context).textTheme.titleLarge,
              ),
              const SizedBox(height: 12),
              
              // نموذج إنشاء النقلة
              TripForm(
                onSubmit: (tripData) {
                  final newTrip = Trip(
                    id: const Uuid().v4(),
                    customerName: tripData['customerName'],
                    customerPhone: tripData['customerPhone'],
                    pickupLocationName: tripData['pickupLocationName'],
                    pickupLat: tripData['pickupLat'],
                    pickupLng: tripData['pickupLng'],
                    dropoffLocationName: tripData['dropoffLocationName'],
                    dropoffLat: tripData['dropoffLat'],
                    dropoffLng: tripData['dropoffLng'],
                    price: tripData['price'],
                    createdAt: DateTime.now(),
                  );
                  
                  // إظهار حوار لاختيار السائق قبل الإضافة
                  _showDriverSelectionDialog(context, newTrip);
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
