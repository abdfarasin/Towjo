import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/trip.dart';
import '../providers/app_provider.dart';
import '../widgets/trip_card.dart';

class DriverScreen extends StatefulWidget {
  final String driverId;

  const DriverScreen({Key? key, required this.driverId}) : super(key: key);

  @override
  State<DriverScreen> createState() => _DriverScreenState();
}

class _DriverScreenState extends State<DriverScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('النقلات المسندة إليك'),
        centerTitle: true,
        backgroundColor: Colors.green[700],
      ),
      body: Consumer<AppProvider>(
        builder: (context, appProvider, _) {
          final driverTrips = appProvider.trips
              .where((trip) => trip.driverId == widget.driverId)
              .toList();

          if (driverTrips.isEmpty) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.inbox,
                    size: 64,
                    color: Colors.grey[400],
                  ),
                  const SizedBox(height: 16),
                  Text(
                    'لا توجد نقلات مسندة إليك حالياً',
                    style: TextStyle(
                      color: Colors.grey[600],
                      fontSize: 16,
                    ),
                  ),
                ],
              ),
            );
          }

          return ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: driverTrips.length,
            itemBuilder: (context, index) {
              return TripCard(
                trip: driverTrips[index],
                driverId: widget.driverId,
              );
            },
          );
        },
      ),
    );
  }
}
