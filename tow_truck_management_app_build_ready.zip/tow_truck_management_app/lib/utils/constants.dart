import 'package:flutter/material.dart';

class AppConstants {
  static const double companyCommissionRate = 0.10;
  static const String currency = 'د.ا';
  
  static const Color primaryColor = Color(0xFF1976D2);
  static const Color secondaryColor = Color(0xFF388E3C);
  
  static const String appTitle = 'نظام إدارة الونشات';
}
