import 'package:flutter/material.dart';

class TripForm extends StatefulWidget {
  final Function(Map<String, dynamic>) onSubmit;

  const TripForm({Key? key, required this.onSubmit}) : super(key: key);

  @override
  State<TripForm> createState() => _TripFormState();
}

class _TripFormState extends State<TripForm> {
  final _formKey = GlobalKey<FormState>();
  
  late TextEditingController _customerNameController;
  late TextEditingController _customerPhoneController;
  late TextEditingController _pickupLocationController;
  late TextEditingController _dropoffLocationController;
  late TextEditingController _priceController;

  @override
  void initState() {
    super.initState();
    _customerNameController = TextEditingController();
    _customerPhoneController = TextEditingController();
    _pickupLocationController = TextEditingController();
    _dropoffLocationController = TextEditingController();
    _priceController = TextEditingController();
  }

  @override
  void dispose() {
    _customerNameController.dispose();
    _customerPhoneController.dispose();
    _pickupLocationController.dispose();
    _dropoffLocationController.dispose();
    _priceController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      child: Column(
        children: [
          TextFormField(
            controller: _customerNameController,
            decoration: const InputDecoration(
              labelText: 'اسم العميل',
              border: OutlineInputBorder(),
            ),
            validator: (value) {
              if (value == null || value.isEmpty) {
                return 'يرجى إدخال اسم العميل';
              }
              return null;
            },
          ),
          const SizedBox(height: 12),
          TextFormField(
            controller: _customerPhoneController,
            decoration: const InputDecoration(
              labelText: 'رقم هاتف العميل',
              border: OutlineInputBorder(),
            ),
            validator: (value) {
              if (value == null || value.isEmpty) {
                return 'يرجى إدخال رقم الهاتف';
              }
              return null;
            },
          ),
          const SizedBox(height: 12),
          TextFormField(
            controller: _pickupLocationController,
            decoration: const InputDecoration(
              labelText: 'موقع الاستلام',
              border: OutlineInputBorder(),
            ),
            validator: (value) {
              if (value == null || value.isEmpty) {
                return 'يرجى إدخال موقع الاستلام';
              }
              return null;
            },
          ),
          const SizedBox(height: 12),
          TextFormField(
            controller: _dropoffLocationController,
            decoration: const InputDecoration(
              labelText: 'موقع التوصيل',
              border: OutlineInputBorder(),
            ),
            validator: (value) {
              if (value == null || value.isEmpty) {
                return 'يرجى إدخال موقع التوصيل';
              }
              return null;
            },
          ),
          const SizedBox(height: 12),
          TextFormField(
            controller: _priceController,
            decoration: const InputDecoration(
              labelText: 'السعر (د.ا)',
              border: OutlineInputBorder(),
            ),
            keyboardType: TextInputType.number,
            validator: (value) {
              if (value == null || value.isEmpty) {
                return 'يرجى إدخال السعر';
              }
              if (double.tryParse(value) == null) {
                return 'يرجى إدخال رقم صحيح';
              }
              return null;
            },
          ),
          const SizedBox(height: 16),
          ElevatedButton(
            onPressed: () {
              if (_formKey.currentState!.validate()) {
                widget.onSubmit({
                  'customerName': _customerNameController.text,
                  'customerPhone': _customerPhoneController.text,
                  'pickupLocationName': _pickupLocationController.text,
                  'pickupLat': 31.9539,
                  'pickupLng': 35.9106,
                  'dropoffLocationName': _dropoffLocationController.text,
                  'dropoffLat': 31.9454,
                  'dropoffLng': 35.9284,
                  'price': double.parse(_priceController.text),
                });
                
                _customerNameController.clear();
                _customerPhoneController.clear();
                _pickupLocationController.clear();
                _dropoffLocationController.clear();
                _priceController.clear();
              }
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.blue[700],
              padding: const EdgeInsets.symmetric(vertical: 12),
            ),
            child: const SizedBox(
              width: double.infinity,
              child: Center(
                child: Text(
                  'إنشاء النقلة',
                  style: TextStyle(color: Colors.white),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
