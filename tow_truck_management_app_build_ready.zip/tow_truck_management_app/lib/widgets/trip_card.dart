import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/trip.dart';
import '../providers/app_provider.dart';

class TripCard extends StatelessWidget {
  final Trip trip;
  final String driverId;

  const TripCard({
    Key? key,
    required this.trip,
    required this.driverId,
  }) : super(key: key);

  String _getStatusText(TripStatus status) {
    switch (status) {
      case TripStatus.pending:
        return 'قيد الانتظار';
      case TripStatus.accepted:
        return 'تم القبول';
      case TripStatus.onWay:
        return 'في الطريق';
      case TripStatus.pickedUp:
        return 'تم الاستلام';
      case TripStatus.completed:
        return 'مكتملة';
      case TripStatus.cancelled:
        return 'ملغاة';
    }
  }

  Color _getStatusColor(TripStatus status) {
    switch (status) {
      case TripStatus.pending:
        return Colors.orange;
      case TripStatus.accepted:
        return Colors.blue;
      case TripStatus.onWay:
        return Colors.purple;
      case TripStatus.pickedUp:
        return Colors.indigo;
      case TripStatus.completed:
        return Colors.green;
      case TripStatus.cancelled:
        return Colors.red;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  trip.customerName,
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 12,
                    vertical: 6,
                  ),
                  decoration: BoxDecoration(
                    color: _getStatusColor(trip.status),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    _getStatusText(trip.status),
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 12,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                const Icon(Icons.phone, size: 16),
                const SizedBox(width: 8),
                Text(trip.customerPhone),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                const Icon(Icons.location_on, size: 16, color: Colors.green),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'من: ${trip.pickupLocationName}',
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                const Icon(Icons.location_on, size: 16, color: Colors.red),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'إلى: ${trip.dropoffLocationName}',
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'السعر: ${trip.price.toStringAsFixed(2)} د.ا',
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                ElevatedButton(
                  onPressed: trip.status != TripStatus.completed && trip.status != TripStatus.cancelled
                      ? () {
                          TripStatus nextStatus;
                          String message;
                          
                          switch (trip.status) {
                            case TripStatus.pending:
                              nextStatus = TripStatus.accepted;
                              message = 'تم قبول النقلة';
                              break;
                            case TripStatus.accepted:
                              nextStatus = TripStatus.onWay;
                              message = 'أنت الآن في الطريق';
                              break;
                            case TripStatus.onWay:
                              nextStatus = TripStatus.pickedUp;
                              message = 'تم استلام المركبة';
                              break;
                            case TripStatus.pickedUp:
                              nextStatus = TripStatus.completed;
                              message = 'تمت النقلة بنجاح. عمولة الشركة: ${trip.companyCommission.toStringAsFixed(2)} د.ا';
                              break;
                            default:
                              return;
                          }
                          
                          context.read<AppProvider>().updateTripStatus(
                            trip.id,
                            nextStatus,
                          );
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(content: Text(message)),
                          );
                        }
                      : null,
                  child: Text(
                    trip.status == TripStatus.pending ? 'قبول' :
                    trip.status == TripStatus.accepted ? 'بدء الطريق' :
                    trip.status == TripStatus.onWay ? 'تم الاستلام' :
                    trip.status == TripStatus.pickedUp ? 'إكمال' : 'مكتملة'
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
