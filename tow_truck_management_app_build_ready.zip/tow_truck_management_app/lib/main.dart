import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'providers/app_provider.dart';
import 'screens/dispatcher_screen.dart';
import 'screens/driver_screen.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AppProvider()),
      ],
      child: MaterialApp(
        title: 'تطبيق إدارة الونشات',
        theme: ThemeData(
          primarySwatch: Colors.blue,
          useMaterial3: true,
        ),
        home: const HomeScreen(),
      ),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String? _selectedRole;
  String? _selectedDriverId;

  @override
  Widget build(BuildContext context) {
    if (_selectedRole == null) {
      return Scaffold(
        appBar: AppBar(
          title: const Text('تطبيق إدارة الونشات'),
          centerTitle: true,
        ),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(
                Icons.local_shipping,
                size: 80,
                color: Colors.blue,
              ),
              const SizedBox(height: 32),
              const Text(
                'اختر دورك',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 32),
              ElevatedButton(
                onPressed: () {
                  setState(() {
                    _selectedRole = 'dispatcher';
                  });
                },
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 32,
                    vertical: 16,
                  ),
                  backgroundColor: Colors.blue[700],
                ),
                child: const Text(
                  'موزع النقلات',
                  style: TextStyle(
                    fontSize: 16,
                    color: Colors.white,
                  ),
                ),
              ),
              const SizedBox(height: 16),
              ElevatedButton(
                onPressed: () {
                  setState(() {
                    _selectedRole = 'driver_selection';
                  });
                },
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 32,
                    vertical: 16,
                  ),
                  backgroundColor: Colors.green[700],
                ),
                child: const Text(
                  'السائق',
                  style: TextStyle(
                    fontSize: 16,
                    color: Colors.white,
                  ),
                ),
              ),
            ],
          ),
        ),
      );
    }

    if (_selectedRole == 'dispatcher') {
      return Scaffold(
        appBar: AppBar(
          title: const Text('تطبيق إدارة الونشات'),
          centerTitle: true,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back),
            onPressed: () {
              setState(() {
                _selectedRole = null;
              });
            },
          ),
        ),
        body: const DispatcherScreen(),
      );
    }

    if (_selectedRole == 'driver_selection') {
      return Scaffold(
        appBar: AppBar(
          title: const Text('اختر السائق'),
          centerTitle: true,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back),
            onPressed: () {
              setState(() {
                _selectedRole = null;
              });
            },
          ),
        ),
        body: Consumer<AppProvider>(
          builder: (context, appProvider, _) {
            return ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: appProvider.drivers.length,
              itemBuilder: (context, index) {
                final driver = appProvider.drivers[index];
                return Card(
                  margin: const EdgeInsets.only(bottom: 12),
                  child: ListTile(
                    title: Text(driver.name),
                    subtitle: Text(driver.truckType),
                    trailing: const Icon(Icons.arrow_forward),
                    onTap: () {
                      setState(() {
                        _selectedRole = 'driver';
                        _selectedDriverId = driver.id;
                      });
                    },
                  ),
                );
              },
            );
          },
        ),
      );
    }

    if (_selectedRole == 'driver' && _selectedDriverId != null) {
      return Scaffold(
        appBar: AppBar(
          title: const Text('تطبيق إدارة الونشات'),
          centerTitle: true,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back),
            onPressed: () {
              setState(() {
                _selectedRole = 'driver_selection';
                _selectedDriverId = null;
              });
            },
          ),
        ),
        body: DriverScreen(driverId: _selectedDriverId!),
      );
    }

    return const Scaffold(
      body: Center(
        child: CircularProgressIndicator(),
      ),
    );
  }
}
