import 'package:flutter/material.dart';
import '../models/driver.dart';
import '../models/trip.dart';

class AppProvider with ChangeNotifier {
  List<Driver> _drivers = [
    Driver(
      id: '1',
      name: 'أحمد محمد',
      phoneNumber: '0790000001',
      truckType: 'ونش سطحة',
      latitude: 31.9539,
      longitude: 35.9106,
    ),
    Driver(
      id: '2',
      name: 'محمود علي',
      phoneNumber: '0790000002',
      truckType: 'ونش هيدروليك',
      latitude: 31.9454,
      longitude: 35.9284,
    ),
    Driver(
      id: '3',
      name: 'خالد وليد',
      phoneNumber: '0790000003',
      truckType: 'ونش سحب',
      latitude: 31.9631,
      longitude: 35.9303,
    ),
  ];

  List<Trip> _trips = [];

  List<Driver> get drivers => _drivers;
  List<Trip> get trips => _trips;

  void addTrip(Trip trip) {
    _trips.add(trip);
    notifyListeners();
  }

  void assignDriverToTrip(String tripId, String driverId) {
    final index = _trips.indexWhere((t) => t.id == tripId);
    if (index != -1) {
      _trips[index] = Trip(
        id: _trips[index].id,
        customerName: _trips[index].customerName,
        customerPhone: _trips[index].customerPhone,
        pickupLocationName: _trips[index].pickupLocationName,
        pickupLat: _trips[index].pickupLat,
        pickupLng: _trips[index].pickupLng,
        dropoffLocationName: _trips[index].dropoffLocationName,
        dropoffLat: _trips[index].dropoffLat,
        dropoffLng: _trips[index].dropoffLng,
        price: _trips[index].price,
        driverId: driverId,
        status: TripStatus.pending,
        createdAt: _trips[index].createdAt,
      );
      notifyListeners();
    }
  }

  double getTotalCommission() {
    return _trips
        .where((t) => t.status == TripStatus.completed)
        .fold(0, (sum, t) => sum + t.companyCommission);
  }

  void updateTripStatus(String tripId, TripStatus newStatus) {
    final index = _trips.indexWhere((t) => t.id == tripId);
    if (index != -1) {
      _trips[index].status = newStatus;
      notifyListeners();
    }
  }

  Driver? getDriverById(String id) {
    try {
      return _drivers.firstWhere((d) => d.id == id);
    } catch (e) {
      return null;
    }
  }
}
