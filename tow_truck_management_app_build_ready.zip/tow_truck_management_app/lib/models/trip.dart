enum TripStatus { pending, accepted, onWay, pickedUp, completed, cancelled }

class Trip {
  final String id;
  final String customerName;
  final String customerPhone;
  final String pickupLocationName;
  final double pickupLat;
  final double pickupLng;
  final String dropoffLocationName;
  final double dropoffLat;
  final double dropoffLng;
  final double price;
  final String? driverId;
  TripStatus status;
  final DateTime createdAt;

  Trip({
    required this.id,
    required this.customerName,
    required this.customerPhone,
    required this.pickupLocationName,
    required this.pickupLat,
    required this.pickupLng,
    required this.dropoffLocationName,
    required this.dropoffLat,
    required this.dropoffLng,
    required this.price,
    this.driverId,
    this.status = TripStatus.pending,
    required this.createdAt,
  });

  double get companyCommission => price * 0.10;
  double get driverEarnings => price * 0.90;
}
