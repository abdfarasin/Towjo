class Driver {
  final String id;
  final String name;
  final String phoneNumber;
  final String truckType;
  final double latitude;
  final double longitude;
  final bool isAvailable;
  final double rating;

  Driver({
    required this.id,
    required this.name,
    required this.phoneNumber,
    required this.truckType,
    required this.latitude,
    required this.longitude,
    this.isAvailable = true,
    this.rating = 4.5,
  });
}
