package com.example.tow_truck_management_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
